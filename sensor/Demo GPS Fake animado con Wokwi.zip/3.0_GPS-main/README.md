# 3.0_GPS
3.0 GPS + Oled Temático + Wokwi.com (COMO EQUIPO CON REPOSITORIO)
## Integrantes del equipo "Equipo Dinamita"
* AYLIN CASSANDRA PAYAN SAAVEDRA 20212849
* GABRIEL STOYKO MARTINEZ GARCIA 20211808
* EMILIANO GARCIA CORDERO 20211779
* ALEJANDRO JUSTO GARCIA 20212412
* OMAR GARCIA TORRES 20210567
* BRIAN ULISES NAVA VILLAGRANA 19211692
* SAMUEL SALAZAR DIAZ 19211729

Link wokwi : https://wokwi.com/projects/381411706635128833

En esta imagen se esta corriendo el programa. nos muestra 
![](imaganes/oled.png)

![](imaganes/raspber.png)

![](imaganes/serial.png)
